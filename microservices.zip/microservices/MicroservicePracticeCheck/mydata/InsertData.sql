insert into menuitem(id,name,price,actv,dateoflaunch,category,freedelivery) values
(1, "Sandwich", "99.0", true, "2017-03-15","Main Course", true),
(2, "Burger", "129.0", true, "2017-12-23","Main Course", false),
(3, "Pizza", "149.0", true, "2018-08-21","Main Course", false),
(4, "French Fries", "57.0", false, "2017-07-02","Starters", true),
(5, "Chocolate Brownie", "32.0", true, "2022-11-02","Dessert", true);