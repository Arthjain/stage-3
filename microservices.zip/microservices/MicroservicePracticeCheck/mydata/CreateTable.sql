create table menuitem(id long,name varchar(120), price float,actv boolean, dateoflaunch date,category varchar(120), freedelivery boolean);
